<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Our Publications')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto px-6 lg:px-8">
            <div class="w-full">
                <div class="grid grid-cols-1 md:grid-cols-7 gap-0 md:gap-x-2">
                    <div class="col-span-1 md:col-span-5 md:mb-4">
                        <div class="mb-4">Welcome to our Publications Page! Here, you'll find a curated collection of insightful articles, news updates, research papers, and official documents that reflect our latest work and initiatives.
                        </div>
                        <?php if($publications->count()): ?>
                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                                <?php $__currentLoopData = $publications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="border-t-2 border-[#DEC23D] relative inset-0 hover:bg-[#074923] hover:bg-opacity-5 hover:shadow">
                                        <a href="<?php echo e(route('contact-form')); ?>" class="absolute w-full h-full"></a>
                                        <p class="text-sm font-bold  self-end absolute py-1 px-3 bg-[#DEC23D] text-gray-100 rounded-br-lg"><?php echo e($publication->type); ?></p>
                                        <div class="mt-10 mb-4">
                                            <p class="font-extrabold text-lg m-2"><?php echo e($publication->name); ?></p>
                                            <p class="text-justify m-2"><?php echo e($publication->description); ?></p>
                                            <div class="w-full flex justify-start items-center">
                                                <a href="<?php echo e($publication->file); ?>" class=" bg-[#074923] hover:bg-transparent hover:border-[#074923] hover:text-[#074923] py-1 px-5 m-2 rounded text-gray-100">
                                                    <i class="fas fa-download text-gray-100"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="p-4">
                                <?php echo e($publications->links()); ?>

                            </div>
                        <?php else: ?>
                            <div class="max-w-7xl mx-auto lg:px-8 mb-4">
                                <div class="flex justify-center items-centers p-6 bg-opacity-50-shadow text-bold bg-[#074923] text-gray-100">
                                    No publications available at the moment.
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="lg:px-5 col-span-1 md:col-span-2">
                        <div class="font-bold mb-4">Vacancies</div>
                        <div class="">
                            <?php if($vacancies->count()): ?>
                                <?php $__currentLoopData = $vacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacancy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="h-full w-full hover:shadow-md p-1 hover:p-2">
                                        <a href="<?php echo e(route('vacancies-read', $vacancy->id)); ?>" class="">
                                            <p class=""><?php echo e($vacancy->title); ?> - attainable in <?php echo e($vacancy->location); ?></p>
                                            <p class="text-sm text-[#074923] font-bold"><?php echo e($vacancy->type); ?></p>
                                        </a>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="max-w-7xl mx-auto px-6 lg:px-8 mb-4">
                                    <div class="flex justify-center items-centers p-6 bg-opacity-50-shadow text-bold bg-[#074923] text-gray-100">
                                        No vacancies available at the moment.
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Projects\Temp\CRAuth01\resources\views/publications.blade.php ENDPATH**/ ?>