



<img src="<?php echo e(asset('assets/401743617_n.svg')); ?>" alt="logo" class="">
<?php /**PATH C:\Users\mwina\PhpstormProjects\cramw\resources\views/components/application-logo.blade.php ENDPATH**/ ?>