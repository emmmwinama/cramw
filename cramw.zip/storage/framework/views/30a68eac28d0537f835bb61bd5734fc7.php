<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('News and Events')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <?php if($featuredPosts->count()): ?>
        <div class="max-w-7xl mx-auto px-6 lg:px-8 mb-4">
            <div class="grid grid-cols-1 md:grid-cols-5">
                <div class="hover:shadow col-span-1 md:col-span-3">
                    <div class="col-span-3 relative">
                        <img src="<?php echo e(asset('storage/'.$featuredPosts[0]->image)); ?>" alt="alt" class="w-full h-full object-contain">
                        <div class="absolute bg-black bg-opacity-50 inset-0 w-full h-full flex">
                            <a href="<?php echo e(route('newsread', $featuredPosts[0]->id)); ?>" class="text-2xl text-gray-100 w-full h-full flex items-end justify-center p-4 text-justify hover:p-3 capitalize">
                                <?php echo e($featuredPosts[0]->title); ?>

                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-span-1 md:col-span-2 md:pl-4 flex flex-col justify-between">
                    <?php $__currentLoopData = range(1, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($featuredPosts[$index])): ?>
                        <a href="<?php echo e(route('newsread', $featuredPosts[$index]->id)); ?>" class="hover:px-1 hover:shadow mb-4">
                            <div class="grid grid-cols-3 gap-x-1">
                                <div class="col-span-2 pr-3 text-justify">
                                    <?php echo e($featuredPosts[$index]->title); ?>

                                </div>
                                <div class="col-span-1">
                                    <img src="<?php echo e(asset('storage/'.$featuredPosts[$index]->image)); ?>" alt="alt" class="w-full h-full object-cover"> <!-- Assuming your item has an image property -->
                                </div>
                            </div>
                        </a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="md:my-12">
                <div class="font-bold text-2xl capitalize">Other News and Events</div>
                <?php if($otherPosts->count()): ?>
                <div class="grid grid-cols-1 md:grid-cols-3 md:pt-12 md:gap-3 gap-y-3">
                    <?php $__currentLoopData = $otherPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-span-1 mb-4 hover:px-1 hover:shadow">
                        <a href="<?php echo e(route('newsread', $post->id)); ?>" class="">
                            <div class="grid grid-cols-3 gap-x-1">
                                <div class="col-span-2 pr-3 text-justify"><?php echo e($post->title); ?></div>
                                <div class="col-span-1">
                                    <img src="<?php echo e(asset('storage/'.$post->image)); ?>" alt="alt" class="w-full h-full object-cover">
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                    <div class="p-4">
                        <?php echo e($otherPosts->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php else: ?>
            <div class="max-w-7xl mx-auto px-6 lg:px-8 mb-4">
                <div class="flex justify-center items-centers p-6 bg-opacity-50-shadow text-bold bg-[#074923] text-gray-100">
                    No news and events information available at the moment.
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Projects\Temp\CRAuth01\resources\views/news.blade.php ENDPATH**/ ?>