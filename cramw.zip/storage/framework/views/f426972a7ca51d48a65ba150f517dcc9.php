



<img src="<?php echo e(asset('assets/401743617_n.svg')); ?>" alt="logo" class="">
<?php /**PATH /home/cra/CRAuth01/resources/views/components/application-logo.blade.php ENDPATH**/ ?>