<footer class="py-12 bg-teal-950 text-gray-100">
    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 ">
        <div class="grid grid-cols-1 md:grid-cols-4 border-b-4 border-gray-300 pb-12">
            <div class="col-span-1">
                <div class="w-[10rem]">
                    <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'block fill-current text-gray-800 dark:text-gray-200']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block fill-current text-gray-800 dark:text-gray-200']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="col-span-1 md:col-span-3 grid grid-cols-1 md:grid-cols-3">

                <div class="col-span-1 flex flex-col items-center justify-center pt-2">
                    <a href="<?php echo e(route('home')); ?>" class="uppercase">Home</a>
                    <a href="<?php echo e(route('about')); ?>" class="uppercase">About US</a>
                    <a href="<?php echo e(route('contact')); ?>" class="uppercase">Contact</a>
                    <a href="<?php echo e(route('licenses')); ?>" class="uppercase">Licences</a>
                </div>
                <div class="col-span-1 flex flex-col items-center justify-center pt-2">
                    <a href="<?php echo e(route('publications')); ?>" class="uppercase">Publications</a>
                    <a href="<?php echo e(route('news')); ?>" class="uppercase">News & Events</a>
                    <a href="<?php echo e(route('vacancies')); ?>" class="uppercase">Vacancies</a>
                    <a href="<?php echo e(route('staff')); ?>" class="uppercase">CRA Staff</a>
                </div>
                <div class="col-span-1 flex flex-col items-center justify-center pt-2">
                    <a href="<?php echo e(route('home')); ?>" class="font-bold uppercase mb-2">Other Links</a>
                    <a href="<?php echo e(route('home')); ?>" class="font-bold uppercase">Other Links</a>
                    <a href="<?php echo e(route('home')); ?>" class="font-bold uppercase">Other Links</a>
                    <a href="<?php echo e(route('home')); ?>" class="font-bold uppercase">Other Links</a>
                </div>
            </div>
        </div>
        <div class="pt-12 flex flex-row justify-center items-center">
            <i class="fab fa-facebook text-2xl px-3"></i>
            <i class="fab fa-twitter text-2xl px-3"></i>
            <i class="fab fa-reddit text-2xl px-3"></i>
            <i class="fab fa-youtube text-2xl px-3"></i>
        </div>
    </div>
</footer>
<?php /**PATH C:\Users\mwina\PhpstormProjects\cramw\resources\views/components/footer.blade.php ENDPATH**/ ?>