<section class="py-12 bg-gray-100 dark:bg-transparent text-gray-700 dark:text-gray-100 col-span-1">
    <div class="">
        Address
    </div>
</section>
